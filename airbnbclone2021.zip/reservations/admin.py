from django.contrib import admin
from . import models
# Register your models here.
@admin.register(models.Reservation)
class ResevationAdmin(admin.ModelAdmin):

  """ Resevation Admin Definition """
  pass