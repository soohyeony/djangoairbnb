from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from . import models

# Register your models here.
# 데코레이터는 항상 위에 있어야함, admin 패널에서 User를 본다는 의미
@admin.register(models.User)
# admin.site.register(models.User, CustomUserAdmin)과 같은 의미
class CustomUserAdmin(UserAdmin):

  """ Custom User Admin """
  # # 리스트에 보이는 필드 설정, models.py 참고
  # list_display = ('username', 'gender', 'language', 'currency', 'superhost')
  # # 필터 설정
  # list_filter = ("language","currency","superhost")

  fieldsets = UserAdmin.fieldsets + (
    (
      "Custom Profile",
      {
        "fields": (
          "avatar",
          "gender",
          "bio",
          "birthdate",
          "language",
          "currency",
          "superhost",
        )
      },
    ),
  )